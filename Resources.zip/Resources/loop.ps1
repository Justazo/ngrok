$i = 2147483
do {
    Write-Host $i
    Sleep 2147483
    $i--
} while ($i -gt 0)